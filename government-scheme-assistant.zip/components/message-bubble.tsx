'use client'

import { cn } from '@/lib/utils'
import { SchemeCard, SchemeCardSkeleton } from './scheme-card'
import type { SearchResult } from '@/lib/embeddings'
import { User, Bot } from 'lucide-react'

export interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  schemes?: SearchResult[]
  isLoading?: boolean
  timestamp?: Date
}

interface MessageBubbleProps {
  message: Message
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === 'user'

  return (
    <div
      className={cn(
        'flex gap-3 w-full',
        isUser ? 'justify-end' : 'justify-start'
      )}
    >
      {/* Assistant Avatar */}
      {!isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center">
          <Bot className="w-4 h-4 text-primary-foreground" />
        </div>
      )}

      <div
        className={cn(
          'flex flex-col gap-3 max-w-[85%] md:max-w-[75%]',
          isUser ? 'items-end' : 'items-start'
        )}
      >
        {/* Text Content */}
        {message.content && (
          <div
            className={cn(
              'px-4 py-3 rounded-2xl text-sm leading-relaxed',
              isUser
                ? 'bg-primary text-primary-foreground rounded-br-md'
                : 'bg-card border border-border text-card-foreground rounded-bl-md shadow-sm'
            )}
          >
            {message.content}
          </div>
        )}

        {/* Loading State */}
        {message.isLoading && (
          <div className="space-y-3 w-full">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span>Searching schemes...</span>
            </div>
            <SchemeCardSkeleton />
          </div>
        )}

        {/* Scheme Cards */}
        {message.schemes && message.schemes.length > 0 && (
          <div className="space-y-3 w-full">
            {message.schemes.map((result, index) => (
              <SchemeCard
                key={result.scheme.id}
                scheme={result.scheme}
                confidence={result.confidence}
                relevanceLabel={result.relevanceLabel}
                className="animate-in fade-in slide-in-from-bottom-2 duration-300"
                style={{ animationDelay: `${index * 100}ms` } as React.CSSProperties}
              />
            ))}
          </div>
        )}
      </div>

      {/* User Avatar */}
      {isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
          <User className="w-4 h-4 text-secondary-foreground" />
        </div>
      )}
    </div>
  )
}

// Typing indicator component
export function TypingIndicator() {
  return (
    <div className="flex gap-3 w-full justify-start">
      <div className="shrink-0 w-8 h-8 rounded-full bg-primary flex items-center justify-center">
        <Bot className="w-4 h-4 text-primary-foreground" />
      </div>
      <div className="px-4 py-3 rounded-2xl rounded-bl-md bg-card border border-border shadow-sm">
        <div className="flex gap-1">
          <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>
    </div>
  )
}
