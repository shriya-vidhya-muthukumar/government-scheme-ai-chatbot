'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { MessageBubble, TypingIndicator, type Message } from './message-bubble'
import { SearchBar } from './search-bar'
import type { SearchResult } from '@/lib/embeddings'
import { cn } from '@/lib/utils'

interface ConversationContext {
  lastQuery: string
  lastSchemes: SearchResult[]
  lastViewedScheme: SearchResult | null
  currentOffset: number
}

interface ChatWindowProps {
  initialQuery?: string
  className?: string
}

export function ChatWindow({ initialQuery, className }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'Welcome to Government Scheme Assistant. I can help you discover government schemes based on your needs. Try asking about schemes for women, students, farmers, housing loans, or any specific scheme you want to know about.',
    }
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [context, setContext] = useState<ConversationContext>({
    lastQuery: '',
    lastSchemes: [],
    lastViewedScheme: null,
    currentOffset: 0
  })
  
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const hasProcessedInitialQuery = useRef(false)

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, scrollToBottom])

  // Handle initial query from landing page
  useEffect(() => {
    if (initialQuery && !hasProcessedInitialQuery.current) {
      hasProcessedInitialQuery.current = true
      handleSubmit(initialQuery)
    }
  }, [initialQuery])

  const handleSubmit = async (query: string) => {
    if (!query.trim() || isLoading) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setIsLoading(true)

    // Add loading message
    const loadingMessageId = `loading-${Date.now()}`
    setMessages(prev => [...prev, {
      id: loadingMessageId,
      role: 'assistant',
      content: '',
      isLoading: true
    }])

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          context: {
            lastQuery: context.lastQuery,
            lastSchemesCount: context.lastSchemes.length,
            lastViewedSchemeId: context.lastViewedScheme?.scheme.id || null,
            currentOffset: context.currentOffset
          }
        })
      })

      if (!response.ok) {
        throw new Error('Failed to get response')
      }

      const data = await response.json()

      // Update context based on response
      if (data.schemes && data.schemes.length > 0) {
        setContext(prev => ({
          lastQuery: data.isFollowUp ? prev.lastQuery : query,
          lastSchemes: data.isFollowUp ? [...prev.lastSchemes, ...data.schemes] : data.schemes,
          lastViewedScheme: data.schemes[0],
          currentOffset: data.newOffset || (data.isFollowUp ? prev.currentOffset + data.schemes.length : data.schemes.length)
        }))
      }

      // Remove loading message and add actual response
      setMessages(prev => {
        const filtered = prev.filter(m => m.id !== loadingMessageId)
        return [...filtered, {
          id: `assistant-${Date.now()}`,
          role: 'assistant',
          content: data.message,
          schemes: data.schemes,
          timestamp: new Date()
        }]
      })
    } catch (error) {
      console.error('[v0] Chat error:', error)
      setMessages(prev => {
        const filtered = prev.filter(m => m.id !== loadingMessageId)
        return [...filtered, {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: 'I apologize, but I encountered an error while processing your request. Please try again.',
          timestamp: new Date()
        }]
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="sticky bottom-0 border-t border-border bg-background p-4">
        <SearchBar
          onSubmit={handleSubmit}
          placeholder="Ask about government schemes..."
          isLoading={isLoading}
          variant="chat"
          autoFocus
        />
        <p className="text-center text-xs text-muted-foreground mt-2">
          Press Enter to send. Try &quot;any more schemes?&quot; or &quot;tell me more&quot;
        </p>
      </div>
    </div>
  )
}
