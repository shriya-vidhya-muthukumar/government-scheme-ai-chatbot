'use client'

import { cn } from '@/lib/utils'
import type { Scheme } from '@/lib/schemes-data'
import { Progress } from '@/components/ui/progress'
import { openMySchemeInNewTab } from '@/lib/myscheme-urls'

interface SchemeCardProps {
  scheme: Scheme
  confidence?: number
  relevanceLabel?: string
  expanded?: boolean
  onExpand?: () => void
  className?: string
}

export function SchemeCard({
  scheme,
  confidence,
  relevanceLabel,
  expanded = true,
  onExpand,
  className
}: SchemeCardProps) {
  const getRelevanceBadgeColor = (label: string) => {
    switch (label) {
      case 'Very High Relevance':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200'
      case 'High Relevance':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'Relevant':
        return 'bg-slate-100 text-slate-700 border-slate-200'
      default:
        return 'bg-gray-100 text-gray-600 border-gray-200'
    }
  }

  const getConfidenceColor = (score: number) => {
    if (score >= 90) return 'bg-emerald-500'
    if (score >= 80) return 'bg-blue-500'
    if (score >= 70) return 'bg-amber-500'
    return 'bg-slate-400'
  }

  return (
    <div
      className={cn(
        'relative bg-card rounded-lg shadow-sm border border-border overflow-hidden transition-all duration-200 hover:shadow-md',
        'border-l-4 border-l-primary',
        className
      )}
    >
      {/* Header */}
      <div className="p-4 pb-3">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-semibold text-foreground text-base leading-tight">
            {scheme.name}
          </h3>
          {relevanceLabel && (
            <span
              className={cn(
                'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border shrink-0',
                getRelevanceBadgeColor(relevanceLabel)
              )}
            >
              {relevanceLabel}
            </span>
          )}
        </div>

        {/* Confidence Score */}
        {confidence !== undefined && (
          <div className="mt-3 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground font-medium">Confidence Score</span>
              <span className="font-semibold text-foreground">{confidence}%</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all duration-500', getConfidenceColor(confidence))}
                style={{ width: `${confidence}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Content Sections */}
      {expanded && (
        <div className="px-4 pb-4 space-y-4">
          {/* Description */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-semibold text-primary uppercase tracking-wide">
              Description
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {scheme.description}
            </p>
          </div>

          {/* Eligibility */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-semibold text-primary uppercase tracking-wide">
              Eligibility
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {scheme.eligibility}
            </p>
          </div>

          {/* Benefits */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-semibold text-primary uppercase tracking-wide">
              Benefits
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {scheme.benefits}
            </p>
          </div>

          {/* Category Tag & Official Source Button */}
          <div className="pt-4 flex items-center justify-between gap-3 border-t border-border flex-wrap">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-secondary text-secondary-foreground">
                {scheme.category}
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Verified
              </span>
            </div>
            <button
              onClick={() => openMySchemeInNewTab(scheme.id)}
              className={cn(
                'inline-flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold',
                'bg-primary text-primary-foreground hover:bg-primary/85',
                'transition-all duration-200 whitespace-nowrap active:scale-95',
                'shadow-sm hover:shadow-md'
              )}
              title="Visit official scheme page on MyScheme.gov.in"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
              Visit Official Site
            </button>
          </div>
        </div>
      )}

      {/* Expand Button (for collapsed state) */}
      {!expanded && onExpand && (
        <div className="px-4 pb-4">
          <button
            onClick={onExpand}
            className="text-sm text-primary hover:text-primary/80 font-medium transition-colors"
          >
            Show more details
          </button>
        </div>
      )}
    </div>
  )
}

// Compact card variant for featured/landing page
export function SchemeCardCompact({
  scheme,
  onClick,
  className
}: {
  scheme: Scheme
  onClick?: () => void
  className?: string
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'bg-card rounded-lg shadow-sm border border-border p-4 cursor-pointer transition-all duration-200',
        'hover:shadow-md hover:border-primary/30 hover:-translate-y-0.5',
        'border-l-4 border-l-primary',
        className
      )}
    >
      <h3 className="font-semibold text-foreground text-sm leading-tight mb-2">
        {scheme.name}
      </h3>
      <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
        {scheme.description}
      </p>
      <div className="mt-3">
        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-secondary text-secondary-foreground">
          {scheme.category}
        </span>
      </div>
    </div>
  )
}

// Skeleton loading state
export function SchemeCardSkeleton() {
  return (
    <div className="bg-card rounded-lg shadow-sm border border-border overflow-hidden border-l-4 border-l-muted animate-pulse">
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="h-5 bg-muted rounded w-3/4" />
          <div className="h-5 bg-muted rounded w-20" />
        </div>
        <div className="mt-3 space-y-1.5">
          <div className="flex justify-between">
            <div className="h-3 bg-muted rounded w-24" />
            <div className="h-3 bg-muted rounded w-8" />
          </div>
          <div className="h-1.5 bg-muted rounded-full" />
        </div>
      </div>
      <div className="px-4 pb-4 space-y-4">
        <div className="space-y-2">
          <div className="h-3 bg-muted rounded w-20" />
          <div className="h-4 bg-muted rounded w-full" />
          <div className="h-4 bg-muted rounded w-5/6" />
        </div>
        <div className="space-y-2">
          <div className="h-3 bg-muted rounded w-16" />
          <div className="h-4 bg-muted rounded w-full" />
          <div className="h-4 bg-muted rounded w-4/5" />
        </div>
        <div className="space-y-2">
          <div className="h-3 bg-muted rounded w-14" />
          <div className="h-4 bg-muted rounded w-full" />
        </div>
      </div>
    </div>
  )
}
