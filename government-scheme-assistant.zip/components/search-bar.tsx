'use client'

import { useState, useRef, useEffect, type FormEvent, type KeyboardEvent } from 'react'
import { cn } from '@/lib/utils'
import { Search, Send, Loader2 } from 'lucide-react'

interface SearchBarProps {
  onSubmit: (query: string) => void
  placeholder?: string
  isLoading?: boolean
  variant?: 'default' | 'chat'
  autoFocus?: boolean
  className?: string
}

export function SearchBar({
  onSubmit,
  placeholder = 'Search for government schemes...',
  isLoading = false,
  variant = 'default',
  autoFocus = false,
  className
}: SearchBarProps) {
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus()
    }
  }, [autoFocus])

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    if (query.trim() && !isLoading) {
      onSubmit(query.trim())
      setQuery('')
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSubmit(e)
    }
  }

  if (variant === 'chat') {
    return (
      <form onSubmit={handleSubmit} className={cn('relative', className)}>
        <div className="flex items-center gap-2 bg-card border border-border rounded-xl shadow-lg p-2">
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            disabled={isLoading}
            className={cn(
              'flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground',
              'px-3 py-2 outline-none',
              'disabled:opacity-50'
            )}
          />
          <button
            type="submit"
            disabled={!query.trim() || isLoading}
            className={cn(
              'shrink-0 w-10 h-10 rounded-lg flex items-center justify-center',
              'bg-primary text-primary-foreground',
              'transition-all duration-200',
              'hover:bg-primary/90 active:scale-95',
              'disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100'
            )}
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </button>
        </div>
      </form>
    )
  }

  // Default landing page variant
  return (
    <form onSubmit={handleSubmit} className={cn('relative', className)}>
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={isLoading}
          className={cn(
            'w-full h-14 pl-12 pr-32 rounded-xl',
            'bg-card border border-border shadow-lg',
            'text-foreground placeholder:text-muted-foreground',
            'outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/50',
            'transition-all duration-200',
            'disabled:opacity-50'
          )}
        />
        <button
          type="submit"
          disabled={!query.trim() || isLoading}
          className={cn(
            'absolute right-2 top-1/2 -translate-y-1/2',
            'h-10 px-5 rounded-lg',
            'bg-primary text-primary-foreground font-medium text-sm',
            'transition-all duration-200',
            'hover:bg-primary/90 active:scale-95',
            'disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100',
            'flex items-center gap-2'
          )}
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Searching</span>
            </>
          ) : (
            <span>Search</span>
          )}
        </button>
      </div>
      <p className="text-center text-xs text-muted-foreground mt-3">
        Try: &quot;schemes for women&quot;, &quot;student scholarships&quot;, &quot;housing loans&quot;
      </p>
    </form>
  )
}
