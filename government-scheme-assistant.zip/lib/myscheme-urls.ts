/**
 * Maps scheme IDs to their official MyScheme.gov.in URLs
 * Each scheme has a dedicated page on the official government portal
 */
const schemeUrlMap: Record<string, string> = {
  'pm-mudra-yojana': 'https://www.myscheme.gov.in/schemes/pmmy',
  'pm-kisan': 'https://www.myscheme.gov.in/schemes/pm-kisan',
  'sukanya-samriddhi': 'https://www.myscheme.gov.in/schemes/sukanya-samriddhi',
  'pm-awas-yojana-urban': 'https://www.myscheme.gov.in/schemes/pmayu',
  'pm-awas-yojana-gramin': 'https://www.myscheme.gov.in/schemes/pmay-g',
  'pm-ujjwala': 'https://www.myscheme.gov.in/schemes/ujjwala',
  'national-scholarship': 'https://www.myscheme.gov.in/schemes/nsp',
  'ayushman-bharat': 'https://www.myscheme.gov.in/schemes/ab-pmjay',
  'stand-up-india': 'https://www.myscheme.gov.in/schemes/strtupmpr',
  'pm-vishwakarma': 'https://www.myscheme.gov.in/schemes/pmvs',
  'pm-jan-dhan': 'https://www.myscheme.gov.in/schemes/pmjdy',
  'pm-kaushal-vikas': 'https://www.myscheme.gov.in/schemes/pmkvy',
  'mahila-samman': 'https://www.myscheme.gov.in/schemes/mssc',
  'atal-pension': 'https://www.myscheme.gov.in/schemes/apy',
  'pm-svanidhi': 'https://www.myscheme.gov.in/schemes/pm-svanidhi',
  'beti-bachao': 'https://www.myscheme.gov.in/schemes/bbbp',
};

/**
 * Get the official MyScheme URL for a given scheme ID
 * Falls back to homepage if scheme not found
 */
function getMySchemeUrl(schemeId: string): string {
  return schemeUrlMap[schemeId] || 'https://www.myscheme.gov.in/';
}

/**
 * Open scheme's official page on MyScheme.gov.in in a new tab
 * @param schemeId - The ID of the scheme
 */
export function openMySchemeInNewTab(schemeId: string): void {
  const url = getMySchemeUrl(schemeId);
  window.open(url, '_blank', 'noopener,noreferrer');
}
