export interface Scheme {
  id: string
  name: string
  description: string
  eligibility: string
  benefits: string
  category: string
  target_group: string
  keywords: string[]
}

export const schemes: Scheme[] = [
  {
    id: "pm-mudra-yojana",
    name: "Pradhan Mantri Mudra Yojana (PMMY)",
    description: "A flagship scheme launched by the Government of India to provide loans up to Rs. 10 lakh to non-corporate, non-farm small and micro enterprises. The scheme aims to bring entrepreneurship to the doorstep of young, educated, or skilled workers who aspire to become first-generation entrepreneurs.",
    eligibility: "Any Indian citizen who has a business plan for a non-farm sector income generating activity such as manufacturing, processing, trading, or service sector and whose credit need is less than Rs. 10 lakh can approach either a Bank, MFI, or NBFC for availing of Micro Units Development and Refinance Agency (MUDRA) loans.",
    benefits: "Loans available under three categories: Shishu (up to Rs. 50,000), Kishore (Rs. 50,001 to Rs. 5 lakh), and Tarun (Rs. 5,00,001 to Rs. 10 lakh). No collateral required. Flexible repayment options with tenure up to 5 years.",
    category: "Business and Entrepreneurship",
    target_group: "entrepreneurs,small business owners,self-employed",
    keywords: ["mudra", "loan", "business", "entrepreneur", "small business", "pmmy", "startup", "self-employment"]
  },
  {
    id: "pm-kisan",
    name: "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)",
    description: "A central sector scheme with 100% funding from Government of India. It provides income support to all landholding farmer families across the country, to supplement their financial needs for procuring various inputs related to agriculture and allied activities.",
    eligibility: "All landholding farmer families with cultivable land are eligible. The scheme excludes institutional landholders, farmer families holding constitutional posts, serving or retired officers and employees of State/Central Government, PSUs, and Pensioners.",
    benefits: "Direct income support of Rs. 6,000 per year in three equal installments of Rs. 2,000 each, directly transferred to the bank accounts of eligible farmer families through Direct Benefit Transfer (DBT) mode.",
    category: "Agriculture",
    target_group: "farmers,agricultural workers,rural population",
    keywords: ["kisan", "farmer", "agriculture", "farming", "rural", "income support", "direct benefit"]
  },
  {
    id: "sukanya-samriddhi",
    name: "Sukanya Samriddhi Yojana",
    description: "A government-backed savings scheme launched as part of Beti Bachao Beti Padhao campaign. The scheme is targeted at parents of girl children, encouraging them to build a fund for the future education and marriage expenses of their female child.",
    eligibility: "Account can be opened for a girl child below 10 years of age. Only one account per girl child is allowed. A family can open maximum two accounts for two girl children. Guardian must be a resident Indian.",
    benefits: "High interest rate of 8.2% per annum (subject to revision). Tax benefits under Section 80C. Partial withdrawal allowed after girl turns 18. Maturity after 21 years from account opening.",
    category: "Women and Child Development",
    target_group: "women,girls,parents,families",
    keywords: ["sukanya", "girl child", "women", "savings", "education", "daughter", "beti", "female"]
  },
  {
    id: "pm-awas-yojana-urban",
    name: "Pradhan Mantri Awas Yojana - Urban (PMAY-U)",
    description: "A flagship Mission of Government of India implemented by Ministry of Housing and Urban Affairs, aimed at addressing the housing requirement of urban poor including slum dwellers through ensuring a pucca house to all eligible urban households by the year 2022.",
    eligibility: "Beneficiary family should not own a pucca house in any part of India. Beneficiary family should not have availed central assistance under any housing scheme. Annual household income should be up to Rs. 18 lakh for different categories.",
    benefits: "Interest subsidy on home loans ranging from 3% to 6.5%. Direct assistance for construction or enhancement of houses. Credit linked subsidy for EWS, LIG, MIG-I, and MIG-II categories.",
    category: "Housing",
    target_group: "urban poor,low income groups,middle income groups,slum dwellers",
    keywords: ["housing", "home", "awas", "urban", "house", "construction", "subsidy", "pmay"]
  },
  {
    id: "pm-awas-yojana-gramin",
    name: "Pradhan Mantri Awas Yojana - Gramin (PMAY-G)",
    description: "A social welfare flagship programme of the Government of India to provide housing for the rural poor in India. The objective is to provide a pucca house with basic amenities to all houseless and those living in kutcha and dilapidated houses by 2024.",
    eligibility: "Households with no house or living in zero, one, or two room kutcha house. Households having no adult member between age 16 to 59. Households having disabled member with no able-bodied member. SC/ST households, minorities, and others.",
    benefits: "Financial assistance of Rs. 1.20 lakh in plain areas and Rs. 1.30 lakh in hilly/difficult areas. Additional Rs. 12,000 for toilet construction under SBM-G. 90/95 days of unskilled labor wages under MGNREGA.",
    category: "Housing",
    target_group: "rural poor,below poverty line,scheduled castes,scheduled tribes",
    keywords: ["housing", "home", "awas", "rural", "village", "gramin", "construction", "poor"]
  },
  {
    id: "pm-ujjwala",
    name: "Pradhan Mantri Ujjwala Yojana (PMUY)",
    description: "A scheme launched by Ministry of Petroleum and Natural Gas for providing LPG connections to women from Below Poverty Line (BPL) households. The scheme aims to safeguard the health of women and children by providing them with clean cooking fuel.",
    eligibility: "Women from BPL households identified through SECC-2011 data. Applicant must be 18 years or above. Household should not have any existing LPG connection. PM Jan Dhan Account or Aadhaar/Bank Account details required.",
    benefits: "Free LPG connection with a financial support of Rs. 1,600 per connection. EMI facility for purchase of stove and first refill. Direct subsidy transfer to bank accounts.",
    category: "Energy and Welfare",
    target_group: "women,below poverty line,rural women,household",
    keywords: ["ujjwala", "lpg", "gas", "cooking", "women", "bpl", "cylinder", "fuel"]
  },
  {
    id: "national-scholarship",
    name: "National Scholarship Portal Schemes",
    description: "A one-stop solution for students seeking various scholarships offered by Central Government, State Governments, and other agencies. The portal provides scholarships for Pre-Matric, Post-Matric, and Merit-cum-Means based categories.",
    eligibility: "Students studying in Class 1 to Post-Doctoral level. Family income criteria varies by scholarship. Must be enrolled in recognized educational institutions. Different scholarships for SC, ST, OBC, Minority, and General categories.",
    benefits: "Financial assistance ranging from Rs. 1,000 to Rs. 50,000 per annum depending on the scholarship. Covers tuition fees, maintenance allowance, and other educational expenses.",
    category: "Education",
    target_group: "students,scholars,youth,minority students",
    keywords: ["scholarship", "student", "education", "study", "college", "university", "school", "merit"]
  },
  {
    id: "ayushman-bharat",
    name: "Ayushman Bharat Pradhan Mantri Jan Arogya Yojana (AB-PMJAY)",
    description: "The world's largest health insurance scheme fully financed by the government. It provides coverage of Rs. 5 lakh per family per year for secondary and tertiary care hospitalization across public and private empaneled hospitals.",
    eligibility: "Families identified based on deprivation and occupational criteria as per SECC database. No age or family size limits. Both rural and urban poor families are covered. Pre-existing conditions covered from day one.",
    benefits: "Health coverage of Rs. 5 lakh per family per year. Covers 3 days of pre-hospitalization and 15 days of post-hospitalization expenses. All family members covered irrespective of age. Cashless treatment at empaneled hospitals.",
    category: "Healthcare",
    target_group: "poor families,below poverty line,rural population,urban poor",
    keywords: ["ayushman", "health", "hospital", "insurance", "medical", "treatment", "pmjay", "healthcare"]
  },
  {
    id: "stand-up-india",
    name: "Stand Up India Scheme",
    description: "A flagship scheme to promote entrepreneurship among SC, ST, and Women entrepreneurs. The scheme facilitates bank loans between Rs. 10 lakh and Rs. 1 crore to at least one SC or ST borrower and at least one woman borrower per bank branch.",
    eligibility: "SC/ST and/or women entrepreneurs above 18 years of age. For non-individual enterprises, at least 51% shareholding and controlling stake should be held by SC/ST and/or woman entrepreneur. Should not be a defaulter to any bank/financial institution.",
    benefits: "Composite loan between Rs. 10 lakh and Rs. 1 crore covering both term loan and working capital. Repayable in 7 years with maximum moratorium period of 18 months. Margin money of 25% can be provided in convergence with eligible schemes.",
    category: "Business and Entrepreneurship",
    target_group: "women,scheduled castes,scheduled tribes,entrepreneurs",
    keywords: ["standup", "women", "sc", "st", "entrepreneur", "business", "loan", "startup"]
  },
  {
    id: "pm-vishwakarma",
    name: "PM Vishwakarma Scheme",
    description: "A central sector scheme launched to support traditional artisans and craftspeople who work with their hands and tools. The scheme provides end-to-end support through recognition, skill upgradation, toolkit incentive, credit support, and market linkage.",
    eligibility: "Artisans and craftspeople working with hands and tools in 18 identified family-based traditional trades. Should be above 18 years of age. Should not have availed loans under similar schemes in past 5 years.",
    benefits: "Recognition through PM Vishwakarma Certificate and ID Card. Skill training with stipend of Rs. 500 per day. Toolkit incentive up to Rs. 15,000. Collateral-free credit up to Rs. 3 lakh at concessional interest rate of 5%.",
    category: "Skill Development",
    target_group: "artisans,craftspeople,traditional workers,skilled workers",
    keywords: ["vishwakarma", "artisan", "craftsman", "traditional", "handicraft", "skill", "tools", "trade"]
  },
  {
    id: "pm-jan-dhan",
    name: "Pradhan Mantri Jan Dhan Yojana (PMJDY)",
    description: "A national mission for financial inclusion to ensure access to financial services namely Banking/Savings and Deposit Accounts, Remittance, Credit, Insurance, and Pension in an affordable manner to all households in the country.",
    eligibility: "Any Indian citizen above 10 years of age who does not have a bank account. KYC documents required. Small accounts can be opened with simplified KYC if normal documents not available.",
    benefits: "Zero balance savings account with RuPay debit card. Accident insurance cover of Rs. 2 lakh. Life insurance cover of Rs. 30,000 for accounts opened before certain date. Overdraft facility up to Rs. 10,000.",
    category: "Financial Inclusion",
    target_group: "unbanked population,poor families,rural population,general public",
    keywords: ["jan dhan", "bank account", "financial inclusion", "savings", "insurance", "banking", "pmjdy"]
  },
  {
    id: "pm-kaushal-vikas",
    name: "Pradhan Mantri Kaushal Vikas Yojana (PMKVY)",
    description: "The flagship scheme of the Ministry of Skill Development and Entrepreneurship implemented by National Skill Development Corporation. It aims to enable Indian youth to take up industry-relevant skill training that helps them secure a better livelihood.",
    eligibility: "Indian nationals between 15-45 years of age. Candidates who are school/college dropouts or unemployed. Should have Aadhaar card and bank account. Prior learning assessment for those with existing skills.",
    benefits: "Free skill training in various job roles. Certification upon successful completion. Monetary reward on certification. Placement assistance in relevant industries.",
    category: "Skill Development",
    target_group: "youth,unemployed,students,school dropouts",
    keywords: ["skill", "training", "kaushal", "employment", "job", "youth", "certification", "pmkvy"]
  },
  {
    id: "mahila-samman",
    name: "Mahila Samman Savings Certificate",
    description: "A one-time new small savings scheme announced in Budget 2023-24 for women and girls. It offers a fixed interest rate and allows partial withdrawal facility, making it an attractive savings option for women.",
    eligibility: "Women and girls of any age. Account can be opened in the name of a minor girl by guardian. Any woman resident of India can open this account. Available until March 2025.",
    benefits: "Fixed interest rate of 7.5% per annum. Maximum deposit of Rs. 2 lakh. Maturity period of 2 years. Partial withdrawal up to 40% of eligible balance after one year.",
    category: "Women and Child Development",
    target_group: "women,girls,female citizens",
    keywords: ["mahila", "women", "savings", "certificate", "female", "deposit", "interest"]
  },
  {
    id: "atal-pension",
    name: "Atal Pension Yojana (APY)",
    description: "A government-backed pension scheme primarily targeted at the unorganized sector workers. It encourages workers in unorganized sector to voluntarily save for their retirement and provides guaranteed minimum pension.",
    eligibility: "Indian citizens between 18-40 years of age. Must have a savings bank account. Aadhaar and mobile number mandatory. Should not be a member of any statutory social security scheme.",
    benefits: "Guaranteed minimum pension of Rs. 1,000 to Rs. 5,000 per month after 60 years. Same amount of pension to spouse after subscriber's death. Return of pension corpus to nominee after both deaths.",
    category: "Pension and Social Security",
    target_group: "unorganized sector workers,self-employed,private sector employees",
    keywords: ["atal", "pension", "retirement", "apy", "senior citizen", "old age", "savings"]
  },
  {
    id: "pm-svanidhi",
    name: "PM Street Vendor's AtmaNirbhar Nidhi (PM SVANidhi)",
    description: "A micro-credit facility scheme for street vendors to provide affordable working capital loan to resume their livelihoods that have been adversely affected due to COVID-19 lockdown.",
    eligibility: "Street vendors in urban areas vending on or before March 24, 2020. Those who have been issued Certificate of Vending or Letter of Recommendation by ULB. Vendors of surrounding development areas.",
    benefits: "Working capital loan of Rs. 10,000 (first tranche), Rs. 20,000 (second), and Rs. 50,000 (third). Interest subsidy of 7%. Cashback incentive on digital transactions up to Rs. 1,200 per year.",
    category: "Livelihood",
    target_group: "street vendors,hawkers,small traders,urban poor",
    keywords: ["svanidhi", "vendor", "street", "hawker", "loan", "urban", "working capital", "micro credit"]
  },
  {
    id: "beti-bachao",
    name: "Beti Bachao Beti Padhao",
    description: "A campaign of the Government of India that aims to generate awareness and improve the efficiency of welfare services intended for girls in India. It addresses the declining child sex ratio and related issues of women empowerment.",
    eligibility: "Focuses on 100 gender critical districts across India. All government departments, institutions, and civil society organizations can participate. Benefits for girl children and their families.",
    benefits: "Awareness campaigns for gender equality. Improved delivery of welfare services for girls. Better enforcement of PC-PNDT Act. Incentives for girl child through various convergent schemes.",
    category: "Women and Child Development",
    target_group: "girl children,women,families,communities",
    keywords: ["beti", "girl", "women", "daughter", "gender", "education", "female", "child"]
  }
]

export function getSchemeById(id: string): Scheme | undefined {
  return schemes.find(scheme => scheme.id === id)
}

export function getSchemesByCategory(category: string): Scheme[] {
  return schemes.filter(scheme => 
    scheme.category.toLowerCase().includes(category.toLowerCase())
  )
}

export function getFeaturedSchemes(count: number = 6): Scheme[] {
  return schemes.slice(0, count)
}
