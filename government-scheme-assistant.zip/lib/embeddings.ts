import { schemes, type Scheme } from './schemes-data'

// Simulated word embeddings using TF-IDF-like approach
// In production, this would use Sentence Transformers or similar

const stopWords = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
  'of', 'with', 'by', 'from', 'is', 'are', 'was', 'were', 'be', 'been',
  'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
  'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need',
  'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we',
  'they', 'what', 'which', 'who', 'whom', 'whose', 'where', 'when', 'why',
  'how', 'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other',
  'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than',
  'too', 'very', 'just', 'also', 'now', 'here', 'there', 'then', 'once',
  'me', 'my', 'any', 'about', 'under', 'over', 'through', 'during', 'before',
  'after', 'above', 'below', 'between', 'into', 'out', 'off', 'up', 'down'
])

// Synonym mapping for better semantic matching
const synonymMap: Record<string, string[]> = {
  'women': ['woman', 'female', 'ladies', 'girl', 'mahila', 'beti', 'daughter', 'mothers', 'mother'],
  'loan': ['credit', 'finance', 'lending', 'borrow', 'money', 'funding', 'debt', 'interest', 'emi'],
  'student': ['scholar', 'learner', 'education', 'college', 'university', 'school', 'studying', 'pupil', 'boy'],
  'scholarship': ['fellowship', 'grant', 'stipend', 'financial aid', 'education funding', 'money for studies'],
  'farmer': ['kisan', 'agriculture', 'farming', 'cultivator', 'agricultural', 'crop', 'crops', 'cultivation', 'rural'],
  'health': ['medical', 'hospital', 'treatment', 'healthcare', 'disease', 'medicine', 'doctor', 'illness', 'sick'],
  'housing': ['home', 'house', 'shelter', 'accommodation', 'awas', 'residence', 'property', 'building'],
  'business': ['entrepreneur', 'enterprise', 'startup', 'company', 'self-employed', 'trade', 'trading'],
  'pension': ['retirement', 'old age', 'senior citizen', 'elderly', 'retired', 'age'],
  'skill': ['training', 'vocational', 'employment', 'job', 'career', 'course', 'learn', 'education'],
  'poor': ['bpl', 'below poverty line', 'economically weaker', 'low income', 'needy', 'poverty', 'poor section'],
  'gas': ['lpg', 'cooking', 'cylinder', 'ujjwala', 'fuel', 'cooking gas', 'energy'],
  'bank': ['banking', 'financial', 'account', 'savings', 'deposit', 'money', 'finance'],
  'insurance': ['coverage', 'protection', 'assurance', 'ayushman', 'health insurance', 'cover'],
  'artisan': ['craftsman', 'vishwakarma', 'handicraft', 'traditional', 'craft', 'artisans'],
  'vendor': ['hawker', 'street seller', 'small trader', 'svanidhi', 'seller', 'shopkeeper'],
  'elderly': ['senior', 'old', 'aged', 'older', 'pensioner', 'retired'],
  'child': ['children', 'kids', 'baby', 'infant', 'son', 'daughter', 'girl', 'boy'],
  'family': ['families', 'household', 'dependents', 'members'],
  'employment': ['job', 'work', 'employment', 'career', 'position', 'hire'],
  'support': ['help', 'assistance', 'aid', 'benefit', 'support']
}

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 2 && !stopWords.has(word))
}

function expandWithSynonyms(tokens: string[]): string[] {
  const expanded = new Set(tokens)
  
  for (const token of tokens) {
    // Check if token is a key in synonym map
    if (synonymMap[token]) {
      synonymMap[token].forEach(syn => expanded.add(syn))
    }
    // Check if token is a synonym value
    for (const [key, synonyms] of Object.entries(synonymMap)) {
      if (synonyms.includes(token)) {
        expanded.add(key)
        synonyms.forEach(syn => expanded.add(syn))
      }
    }
  }
  
  return Array.from(expanded)
}

function createSchemeVector(scheme: Scheme): Map<string, number> {
  const vector = new Map<string, number>()
  
  // Combine all searchable text with weights
  const weightedTexts = [
    { text: scheme.name, weight: 3 },
    { text: scheme.keywords.join(' '), weight: 3 },
    { text: scheme.target_group, weight: 2.5 },
    { text: scheme.category, weight: 2 },
    { text: scheme.description, weight: 1.5 },
    { text: scheme.eligibility, weight: 1 },
    { text: scheme.benefits, weight: 1 }
  ]
  
  for (const { text, weight } of weightedTexts) {
    const tokens = tokenize(text)
    for (const token of tokens) {
      const current = vector.get(token) || 0
      vector.set(token, current + weight)
    }
  }
  
  return vector
}

function createQueryVector(query: string): Map<string, number> {
  const vector = new Map<string, number>()
  const tokens = tokenize(query)
  const expanded = expandWithSynonyms(tokens)
  
  // Original tokens get higher weight
  for (const token of tokens) {
    vector.set(token, 2)
  }
  
  // Expanded synonyms get lower weight
  for (const token of expanded) {
    if (!vector.has(token)) {
      vector.set(token, 1)
    }
  }
  
  return vector
}

function cosineSimilarity(vec1: Map<string, number>, vec2: Map<string, number>): number {
  let dotProduct = 0
  let norm1 = 0
  let norm2 = 0
  
  // Calculate dot product
  for (const [key, value1] of vec1) {
    const value2 = vec2.get(key) || 0
    dotProduct += value1 * value2
  }
  
  // Calculate norms
  for (const value of vec1.values()) {
    norm1 += value * value
  }
  for (const value of vec2.values()) {
    norm2 += value * value
  }
  
  norm1 = Math.sqrt(norm1)
  norm2 = Math.sqrt(norm2)
  
  if (norm1 === 0 || norm2 === 0) return 0
  
  return dotProduct / (norm1 * norm2)
}

// Pre-compute scheme vectors
const schemeVectors = new Map<string, Map<string, number>>()

export function initializeEmbeddings(): void {
  for (const scheme of schemes) {
    schemeVectors.set(scheme.id, createSchemeVector(scheme))
  }
}

// Initialize on module load
initializeEmbeddings()

export interface SearchResult {
  scheme: Scheme
  similarity: number
  confidence: number
  relevanceLabel: 'Very High Relevance' | 'High Relevance' | 'Relevant' | 'Low Relevance'
}

export function searchSchemes(query: string, limit: number = 5, offset: number = 0): SearchResult[] {
  const queryVector = createQueryVector(query)
  const results: { scheme: Scheme; similarity: number }[] = []
  
  for (const scheme of schemes) {
    const schemeVector = schemeVectors.get(scheme.id)
    if (schemeVector) {
      const similarity = cosineSimilarity(queryVector, schemeVector)
      // Only include results with meaningful similarity - increased threshold
      if (similarity > 0.08) {
        results.push({ scheme, similarity })
      }
    }
  }
  
  // Sort by similarity descending
  results.sort((a, b) => b.similarity - a.similarity)
  
  // Apply offset and limit
  const paginatedResults = results.slice(offset, offset + limit)
  
  return paginatedResults.map(({ scheme, similarity }) => {
    // Calibrated confidence score: 70-99
    const normalizedSim = Math.min(similarity, 1)
    const confidence = Math.round(70 + (normalizedSim * 29))
    
    let relevanceLabel: SearchResult['relevanceLabel']
    if (similarity > 0.5) {
      relevanceLabel = 'Very High Relevance'
    } else if (similarity > 0.3) {
      relevanceLabel = 'High Relevance'
    } else if (similarity > 0.1) {
      relevanceLabel = 'Relevant'
    } else {
      relevanceLabel = 'Low Relevance'
    }
    
    return {
      scheme,
      similarity,
      confidence,
      relevanceLabel
    }
  })
}

export function findSchemeByName(query: string): Scheme | null {
  const normalizedQuery = query.toLowerCase()
  
  // Direct name match
  for (const scheme of schemes) {
    const normalizedName = scheme.name.toLowerCase()
    if (normalizedName.includes(normalizedQuery) || normalizedQuery.includes(normalizedName)) {
      return scheme
    }
    
    // Check keywords for specific scheme mentions
    for (const keyword of scheme.keywords) {
      if (normalizedQuery.includes(keyword) && keyword.length > 4) {
        return scheme
      }
    }
  }
  
  return null
}

export function getTotalResultsCount(query: string): number {
  const queryVector = createQueryVector(query)
  let count = 0
  
  for (const scheme of schemes) {
    const schemeVector = schemeVectors.get(scheme.id)
    if (schemeVector) {
      const similarity = cosineSimilarity(queryVector, schemeVector)
      if (similarity > 0.08) {
        count++
      }
    }
  }
  
  return count
}

/**
 * Check if a query is related to government schemes
 * Returns the relevance score (0-1) for scheme-related queries
 */
export function isSchemeQuery(query: string): { isRelevant: boolean; score: number } {
  const schemeRelatedKeywords = [
    'scheme', 'yojana', 'government', 'subsidy', 'grant', 'loan', 'benefit',
    'eligibility', 'apply', 'registration', 'application', 'financial aid',
    'assistance', 'program', 'pension', 'scholarship', 'insurance', 'housing',
    'health', 'education', 'agriculture', 'business', 'employment', 'skill',
    'training', 'support', 'welfare', 'women', 'farmer', 'student', 'poor',
    'elderly', 'children', 'family', 'bank', 'account', 'saving', 'investment',
    'pm', 'pradhan mantri', 'nrega', 'mgnrega', 'ayushman', 'mudra', 'kisan',
    'ujjwala', 'awas', 'jan dhan', 'sukanya', 'beti', 'mahila', 'vishwakarma',
    'svanidhi', 'atal', 'kaushal', 'stand up', 'national scholarship'
  ]
  
  const normalizedQuery = query.toLowerCase()
  const tokens = tokenize(normalizedQuery)
  
  // Count how many scheme-related keywords are in the query
  let matchCount = 0
  for (const keyword of schemeRelatedKeywords) {
    if (normalizedQuery.includes(keyword) || tokens.some(t => t === keyword)) {
      matchCount++
    }
  }
  
  // Calculate relevance score
  const relevanceScore = Math.min(matchCount / 3, 1) // Normalize with 3 as baseline
  
  // A query is scheme-related if it has at least some relevance score
  // This prevents completely unrelated queries from matching
  const isRelevant = relevanceScore > 0 || tokens.some(t => t.length > 4)
  
  return { isRelevant, score: relevanceScore }
}
