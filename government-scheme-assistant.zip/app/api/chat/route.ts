import { NextResponse } from 'next/server'
import { searchSchemes, findSchemeByName, getTotalResultsCount, isSchemeQuery, type SearchResult } from '@/lib/embeddings'
import { getSchemeById, schemes } from '@/lib/schemes-data'

interface ChatContext {
  lastQuery: string
  lastSchemesCount: number
  lastViewedSchemeId: string | null
  currentOffset: number
}

interface ChatRequest {
  query: string
  context: ChatContext
}

// Intent classification
type Intent = 
  | 'search'
  | 'specific_scheme'
  | 'more_schemes'
  | 'tell_more'
  | 'small_talk'
  | 'greeting'
  | 'thanks'
  | 'unclear'

function classifyIntent(query: string, context: ChatContext): Intent {
  const normalizedQuery = query.toLowerCase().trim()
  
  // Greeting patterns
  const greetingPatterns = [
    /^(hi|hello|hey|good\s*(morning|afternoon|evening)|namaste)/i,
    /^how\s+are\s+you/i,
    /^hii?$/i,
    /^hey\s+there/i
  ]
  for (const pattern of greetingPatterns) {
    if (pattern.test(normalizedQuery)) return 'greeting'
  }
  
  // Thanks patterns
  const thanksPatterns = [
    /^(thanks|thank\s*you|thx|ty|great|nice|okay|ok|got\s*it|understood)/i,
    /^(perfect|awesome|cool|great thanks)/i,
    /^thanks.*\!/i
  ]
  for (const pattern of thanksPatterns) {
    if (pattern.test(normalizedQuery)) return 'thanks'
  }
  
  // Small talk patterns
  const smallTalkPatterns = [
    /^(who\s+are\s+you|what\s+(are\s+you|can\s+you\s+do))/i,
    /^what\s+is\s+this|what\s+can\s+i\s+do\s+here/i,
    /^help(\s+me)?$/i,
    /^how\s+does\s+this\s+work/i
  ]
  for (const pattern of smallTalkPatterns) {
    if (pattern.test(normalizedQuery)) return 'small_talk'
  }
  
  // More schemes patterns
  const moreSchemesPatterns = [
    /^(any\s*)?(more|other|additional|next)\s*(schemes?|options?|results?)/i,
    /^show\s*(me\s*)?(more|other|next)/i,
    /^(next|more)$/i,
    /^what\s+else/i,
    /^any\s+more/i,
    /^more\s+results?/i,
    /^show\s+more/i
  ]
  for (const pattern of moreSchemesPatterns) {
    if (pattern.test(normalizedQuery)) return 'more_schemes'
  }
  
  // Tell me more patterns
  const tellMorePatterns = [
    /^(tell|show)\s*(me\s*)?more(\s+(about|regarding)\s*(this|it|that))?/i,
    /^(explain|elaborate|expand|give\s+more)\s*(details?|info(rmation)?)?/i,
    /^more\s+(details?|info(rmation)?|about)/i,
    /^(what|how)\s+(is|are)\s+(the\s+)?(eligibility|benefits?|requirements?|details?)/i,
    /^tell\s+me\s+more/i
  ]
  for (const pattern of tellMorePatterns) {
    if (pattern.test(normalizedQuery)) return 'tell_more'
  }
  
  // Specific scheme patterns - check if query mentions a known scheme
  const specificScheme = findSchemeByName(normalizedQuery)
  if (specificScheme) return 'specific_scheme'
  
  // Check for "about" or "tell me about" patterns
  const aboutPattern = /^(tell\s*(me\s*)?about|what\s+is|explain|describe|info\s+on|details?|eligibility)/i
  if (aboutPattern.test(normalizedQuery)) {
    const cleanedQuery = normalizedQuery.replace(aboutPattern, '').trim()
    if (cleanedQuery.length > 0) {
      const schemeCheck = findSchemeByName(cleanedQuery)
      if (schemeCheck) return 'specific_scheme'
    }
  }
  
  // Very short queries might be unclear
  if (normalizedQuery.length < 3) return 'unclear'
  
  // Default to search
  return 'search'
}

function generateResponse(
  intent: Intent,
  query: string,
  context: ChatContext,
  results: SearchResult[]
): { message: string; schemes: SearchResult[]; isFollowUp: boolean; newOffset?: number } {
  
  switch (intent) {
    case 'greeting':
      return {
        message: 'Hello! I am the Government Scheme Assistant. I can help you discover government schemes based on your needs. You can ask me about schemes for women, farmers, students, housing, healthcare, and more. How can I assist you today?',
        schemes: [],
        isFollowUp: false
      }
    
    case 'thanks':
      return {
        message: 'You are welcome! Feel free to ask if you have any other questions about government schemes. I am here to help you find the right schemes for your needs.',
        schemes: [],
        isFollowUp: false
      }
    
    case 'small_talk':
      return {
        message: 'I am a Government Scheme Assistant, designed to help you discover government schemes and check your eligibility. I use semantic search to understand your needs and find the most relevant schemes. Try asking about specific categories like "schemes for women", "student scholarships", or "housing loans".',
        schemes: [],
        isFollowUp: false
      }
    
    case 'unclear':
      return {
        message: 'I am not sure I understood your query. Could you please be more specific? You can ask me about government schemes by category (women, farmers, students), by type (loans, scholarships, insurance), or by name (PM Mudra Yojana, Ayushman Bharat).',
        schemes: [],
        isFollowUp: false
      }
    
    case 'more_schemes': {
      if (!context.lastQuery || context.lastSchemesCount === 0) {
        return {
          message: 'I do not have a previous search to show more results from. Please tell me what kind of schemes you are looking for.',
          schemes: [],
          isFollowUp: false
        }
      }
      
      const moreResults = searchSchemes(context.lastQuery, 3, context.currentOffset)
      const totalCount = getTotalResultsCount(context.lastQuery)
      
      if (moreResults.length === 0) {
        return {
          message: `I have shown you all ${context.currentOffset} relevant schemes for "${context.lastQuery}". Would you like to search for something different?`,
          schemes: [],
          isFollowUp: true
        }
      }
      
      const remainingCount = totalCount - context.currentOffset - moreResults.length
      const message = remainingCount > 0
        ? `Here are ${moreResults.length} more schemes related to your search. There are ${remainingCount} more schemes available if you would like to see them.`
        : `Here are the remaining ${moreResults.length} schemes related to your search.`
      
      return {
        message,
        schemes: moreResults,
        isFollowUp: true,
        newOffset: context.currentOffset + moreResults.length
      }
    }
    
    case 'tell_more': {
      if (!context.lastViewedSchemeId) {
        return {
          message: 'I do not have a specific scheme to provide more details about. Please ask about a specific scheme or search for schemes first.',
          schemes: [],
          isFollowUp: false
        }
      }
      
      const scheme = getSchemeById(context.lastViewedSchemeId)
      if (!scheme) {
        return {
          message: 'I could not find the scheme you are referring to. Please try searching again.',
          schemes: [],
          isFollowUp: false
        }
      }
      
      // Return detailed view of the scheme with full confidence
      return {
        message: `Here is detailed information about ${scheme.name}. This scheme falls under the ${scheme.category} category and is targeted at ${scheme.target_group.split(',').join(', ')}.`,
        schemes: [{
          scheme,
          similarity: 1,
          confidence: 98,
          relevanceLabel: 'Very High Relevance'
        }],
        isFollowUp: true
      }
    }
    
    case 'specific_scheme': {
      const scheme = findSchemeByName(query)
      if (!scheme) {
        // Fallback to search
        const searchResults = searchSchemes(query, 3)
        if (searchResults.length > 0) {
          return {
            message: `I found ${searchResults.length} scheme${searchResults.length > 1 ? 's' : ''} that might be what you are looking for.`,
            schemes: searchResults,
            isFollowUp: false
          }
        }
        return {
          message: 'I could not find the specific scheme you mentioned. Please check the spelling or try describing what kind of scheme you are looking for.',
          schemes: [],
          isFollowUp: false
        }
      }
      
      return {
        message: `Here is detailed information about ${scheme.name}.`,
        schemes: [{
          scheme,
          similarity: 1,
          confidence: 99,
          relevanceLabel: 'Very High Relevance'
        }],
        isFollowUp: false
      }
    }
    
    case 'search':
    default: {
      // Check if the query is actually related to government schemes
      const { isRelevant, score } = isSchemeQuery(query)
      
      if (!isRelevant && results.length === 0) {
        return {
          message: `I could not find any government schemes related to your query. Please ask about government schemes, such as "schemes for women", "student scholarships", "business loans", "housing assistance", "farmer support", "healthcare benefits", or other government programs. I am specifically designed to help you discover government schemes.`,
          schemes: [],
          isFollowUp: false
        }
      }
      
      if (results.length === 0) {
        return {
          message: `No schemes found matching "${query}". Try different keywords or ask about categories like women, farmers, students, housing, health, business, pensions, or insurance schemes.`,
          schemes: [],
          isFollowUp: false
        }
      }
      
      const totalCount = getTotalResultsCount(query)
      const showingCount = results.length
      const hasMore = totalCount > showingCount
      
      let message = `I found ${totalCount} scheme${totalCount > 1 ? 's' : ''} matching your query.`
      if (totalCount > showingCount) {
        message += ` Showing the top ${showingCount} results. Ask "any more schemes?" to see additional results.`
      }
      
      return {
        message,
        schemes: results,
        isFollowUp: false
      }
    }
  }
}

export async function POST(request: Request) {
  try {
    const body: ChatRequest = await request.json()
    const { query, context } = body
    
    if (!query || typeof query !== 'string') {
      return NextResponse.json(
        { error: 'Query is required' },
        { status: 400 }
      )
    }
    
    const trimmedQuery = query.trim()
    if (trimmedQuery.length === 0) {
      return NextResponse.json(
        { error: 'Query cannot be empty' },
        { status: 400 }
      )
    }
    
    // Classify intent
    const intent = classifyIntent(trimmedQuery, context || {
      lastQuery: '',
      lastSchemesCount: 0,
      lastViewedSchemeId: null,
      currentOffset: 0
    })
    
    // Perform search if needed
    let searchResults: SearchResult[] = []
    if (intent === 'search') {
      searchResults = searchSchemes(trimmedQuery, 3)
    }
    
    // Generate response
    const response = generateResponse(
      intent,
      trimmedQuery,
      context || {
        lastQuery: '',
        lastSchemesCount: 0,
        lastViewedSchemeId: null,
        currentOffset: 0
      },
      searchResults
    )
    
    // Simulate slight delay for realistic feel
    await new Promise(resolve => setTimeout(resolve, 300))
    
    return NextResponse.json(response)
  } catch (error) {
    console.error('[v0] Chat API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
