'use client'

import { useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { SearchBar } from '@/components/search-bar'
import { SchemeCardCompact } from '@/components/scheme-card'
import { getFeaturedSchemes } from '@/lib/schemes-data'
import { Building2, Search, Shield, Zap } from 'lucide-react'

export default function HomePage() {
  const router = useRouter()
  const featuredSchemes = getFeaturedSchemes(6)

  const handleSearch = (query: string) => {
    router.push(`/chat?q=${encodeURIComponent(query)}`)
  }

  const handleSchemeClick = (schemeName: string) => {
    router.push(`/chat?q=${encodeURIComponent(`Tell me about ${schemeName}`)}`)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        
        <div className="container mx-auto px-4 py-16 md:py-24 relative">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            {/* Logo Icon */}
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
              <Building2 className="w-8 h-8 text-primary" />
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight text-balance">
              Government Scheme Assistant
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              AI-powered scheme discovery system. Find government schemes, check eligibility, and get detailed information through natural conversation.
            </p>

            {/* Search Bar */}
            <div className="pt-4 max-w-xl mx-auto">
              <SearchBar
                onSubmit={handleSearch}
                placeholder="Search for schemes (e.g., schemes for women, student scholarships)"
                autoFocus
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="border-t border-border bg-card/50">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-background border border-border">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <Search className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Smart Search</h3>
              <p className="text-sm text-muted-foreground">
                Semantic search understands your needs and finds relevant schemes instantly.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-background border border-border">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Eligibility Check</h3>
              <p className="text-sm text-muted-foreground">
                Get clear eligibility criteria to know if you qualify for a scheme.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-background border border-border">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Instant Results</h3>
              <p className="text-sm text-muted-foreground">
                Get detailed scheme information with confidence scores in seconds.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Schemes Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                Featured Schemes
              </h2>
              <p className="text-muted-foreground">
                Explore popular government schemes or search for specific ones
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {featuredSchemes.map((scheme) => (
                <SchemeCardCompact
                  key={scheme.id}
                  scheme={scheme}
                  onClick={() => handleSchemeClick(scheme.name)}
                />
              ))}
            </div>

            <div className="text-center mt-8">
              <button
                onClick={() => router.push('/chat')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors"
              >
                <Search className="w-4 h-4" />
                Explore All Schemes
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Government Scheme Assistant - AI-powered scheme discovery system
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Disclaimer: This is a demonstration system. Please verify scheme details from official government sources.
          </p>
        </div>
      </footer>
    </div>
  )
}
