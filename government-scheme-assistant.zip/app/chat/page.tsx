'use client'

import { Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { Header } from '@/components/header'
import { ChatWindow } from '@/components/chat-window'

function ChatContent() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get('q') || undefined

  return (
    <div className="flex flex-col h-screen bg-background">
      <Header />
      <main className="flex-1 overflow-hidden">
        <div className="container mx-auto h-full max-w-4xl">
          <ChatWindow initialQuery={initialQuery} />
        </div>
      </main>
    </div>
  )
}

export default function ChatPage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col h-screen bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-muted-foreground">Loading chat...</p>
          </div>
        </main>
      </div>
    }>
      <ChatContent />
    </Suspense>
  )
}
